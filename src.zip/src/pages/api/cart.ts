import type { NextApiRequest, NextApiResponse } from "next";
import clientPromise from "@/modules/mongodb"; // Importando a conexão com o MongoDB

interface ProdutoCarrinho {
  produtoId: string;
  nome: string;
  valor: number;
  quantidade: number;
  img?: string;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { method } = req;
  const login = req.query.userId as string;  // Pega o login da query

  console.log("Login recebido:", login);  // Verifique se o login está correto

  try {
    const client = await clientPromise;
    const db = client.db("paraiba");  // Banco de dados correto

    if (method === "GET") {
      console.log("Buscando carrinho para o login:", login);  // Log para ver o que está sendo buscado

      // Recuperar o carrinho usando o login
      const user = await db.collection("users").findOne({ login });  // Busca na coleção 'users' pelo login
      console.log("Usuário encontrado:", user);  // Verifica se o usuário foi encontrado

      if (user && user.carrinho) {
        return res.status(200).json(user.carrinho);  // Retorna apenas o carrinho
      } else {
        return res.status(404).json({ error: "Carrinho não encontrado" });
      }
    }

  } catch (error) {
    console.error("Erro no carrinho:", error);
    return res.status(500).json({ error: "Erro interno do servidor" });
  }
}
