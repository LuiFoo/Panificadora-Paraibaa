"use client";

import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useUser } from "@/context/UserContext";

export interface CartItem {
  id: string;
  nome: string;
  valor: number;
  quantidade: number;
  img: string;
}

interface CartContextType {
  cartItems: CartItem[];
  totalItems: number;  // Total de itens no carrinho
  removeItem: (id: string) => void;
  updateItemQuantity: (id: string, quantidade: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useUser();
  const login = user?.login || "guest";  // Usa o login para buscar o carrinho

  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const res = await fetch(`/api/cart?userId=${login}`);
        if (!res.ok) throw new Error("Erro ao buscar carrinho");
        const data = await res.json();
        setCartItems(data.produtos || []);  // Pega os produtos do carrinho
      } catch (err) {
        console.error(err);
      }
    };

    fetchCart();
  }, [login]);

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantidade, 0);

  const removeItem = (id: string) => {
    setCartItems((prev) => prev.filter(item => item.id !== id));
  };

  const updateItemQuantity = (id: string, quantidade: number) => {
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantidade } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider value={{ cartItems, totalItems, removeItem, updateItemQuantity, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart deve ser usado dentro de CartProvider");
  return context;
};
